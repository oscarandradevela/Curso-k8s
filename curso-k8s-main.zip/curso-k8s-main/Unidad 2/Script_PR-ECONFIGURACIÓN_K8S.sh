#!/bin/bash

# Solicitar nombre del hostname
echo "Por favor, introduce el nombre del hostname para este nodo:"
read hostname

# Establecer el hostname
echo "Estableciendo el hostname..."
sudo hostnamectl set-hostname "$hostname"

# Solicitar IPs para los nodos
echo "Por favor, introduce la IP del nodo master:"
read ip_master
echo "Por favor, introduce la IP del nodo worker1:"
read ip_worker1

# Configuración DNS en /etc/hosts
echo "Configurando /etc/hosts con las IPs proporcionadas..."
cat <<EOF | sudo tee -a /etc/hosts
$ip_master master.ose.pe master
$ip_worker1 worker1.ose.pe worker1
EOF

# Deshabilitar firewall
echo "Deshabilitando el firewall..."
sudo ufw disable

# Desactivar memoria swap
echo "Desactivando memoria swap..."
swapoff -a
sed -i '/swap.img/s/^/#/' /etc/fstab

# Habilitar módulos de kernel para Containerd
echo "Habilitando módulos de kernel..."
sudo modprobe overlay
sudo modprobe br_netfilter

# Configuración sysctl para habilitar reenvío de IP y netfilter
echo "Configurando sysctl para Kubernetes..."
cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward=1
net.bridge.bridge-nf-call-iptables = 1
EOF
sudo sysctl --system

# Instalar Containerd
echo "Instalando Containerd..."
sudo apt-get update
sudo apt-get install -y apt-transport-https ca-certificates curl gpg
sudo mkdir -p -m 755 /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo tee /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install -y containerd.io

# Configurar Containerd
echo "Configurando Containerd..."
containerd config default | sudo tee /etc/containerd/config.toml
sed -i 's/SystemdCgroup = false/SystemdCgroup = true/' /etc/containerd/config.toml

# Reiniciar servicio de Containerd
echo "Reiniciando servicio de containerd..."
sudo systemctl restart containerd

# Agregar repositorio de Kubernetes
echo "Agregando repositorio de Kubernetes..."
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.30/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.30/deb/ /' | sudo tee /etc/apt/sources.list.d/kubernetes.list
sudo apt-get update

# Instalar kubelet, kubeadm y kubectl
echo "Instalando kubelet, kubeadm y kubectl..."
sudo apt-get install -y kubelet kubeadm kubectl
sudo apt-mark hold kubelet kubeadm kubectl

# Habilitar el servicio kubelet
echo "Habilitando el servicio kubelet..."
sudo systemctl enable --now kubelet

echo "Script completado. La configuración de /etc/hosts se ha realizado, el hostname se ha establecido como '$hostname' y el entorno de Kubernetes está listo."

# Ejecutar una nueva sesión de bash con el hostname actualizado
exec bash


# Simulación de Examen CKAD

---

## Pregunta 1: Core Concepts
**Crea un namespace llamado `ckad-test` y despliega un pod llamado `busybox-pod` dentro de este namespace.**

- El pod debe usar la imagen `busybox`.
- Configura el pod para que ejecute el comando `sleep 3600` como contenedor principal.

1. Proporciona el manifiesto YAML para este pod.
2. Valida que el pod esté en estado `Running`.

---

## Pregunta 2: Configuration
**Crea un ConfigMap llamado `db-config` con los siguientes datos:**
- `DB_HOST=db.example.com`
- `DB_PORT=5432`

Luego:
1. Crea un Deployment llamado `backend` con 2 réplicas que use la imagen `nginx:alpine`.
2. Configura el Deployment para que pase las variables del ConfigMap al contenedor.

---

## Pregunta 3: Pod Design
**Crea un pod llamado `logging-pod` que contenga dos contenedores:**
1. **Contenedor principal:** Usa la imagen `nginx:1.21`.
2. **Contenedor auxiliar:** Usa la imagen `busybox` y ejecuta un comando que escriba un mensaje como `"Log entry $(date)"` en un archivo compartido cada 5 segundos. Usa un volumen de tipo `emptyDir` para compartir datos entre los contenedores.

---

## Pregunta 4: Observability
**Configura un pod llamado `metrics-pod`.**

1. Usa la imagen `nginx`.
2. Configura un `Liveness Probe` que haga una solicitud HTTP a `http://localhost/metrics` y reinicie el pod si no recibe un código de respuesta `200`.
3. Valida los logs del contenedor usando `kubectl logs`.

---

## Pregunta 5: Services & Networking
**Crea un servicio llamado `myapp-service` para exponer un Deployment existente llamado `myapp`.**

1. Configura el Deployment para usar la imagen `nginx`.
2. El servicio debe ser del tipo `NodePort`.
3. Escuchar en el puerto 30080 en los nodos y redirigir el tráfico al puerto 80 de los pods.

---

## Pregunta 6: State Persistence
**Diseña una aplicación con almacenamiento persistente:**

1. Crea un PersistentVolume (PV) llamado `pv-data` con un tamaño de 2Gi, accesible por múltiples nodos y con la clase de almacenamiento `manual`.
2. Crea un PersistentVolumeClaim (PVC) llamado `pvc-data` que requiera 500Mi.
3. Configura un pod llamado `storage-pod` que:
   - Use la imagen `busybox`.
   - Monte el PVC en `/data`.
   - Ejecute un comando que cree un archivo en `/data` llamado `testfile.txt`.

---

## Pregunta 7: Multi-Container Pods 
**Crea un pod llamado `multi-container-pod` con los siguientes detalles:**
1. **Contenedor A:** Usa la imagen `nginx` y expone el puerto 80.
2. **Contenedor B:** Usa la imagen `busybox` y ejecuta un comando que verifique cada 10 segundos si el puerto 80 del Contenedor A está accesible, usando:
wget -q --spider http://localhost:80 && echo "Accessible"

---

## Pregunta 8: Networking Policies
**Crea una NetworkPolicy llamada `allow-nginx` en el namespace `ckad-test`.**

1. **Crea los siguientes pods en el namespace `ckad-test`:**
- Un pod llamado `nginx-pod` usando la imagen `nginx`.
- Un pod llamado `frontend-pod` usando la imagen `busybox` y ejecutando un comando `sleep 3600`.
- Un pod llamado `backend-pod` usando la imagen `busybox` y ejecutando un comando `sleep 3600`.

2. La NetworkPolicy debe cumplir lo siguiente:
- Permitir tráfico entrante al pod `nginx-pod` solo desde pods etiquetados con `app=frontend`.
- Bloquear todo el tráfico entrante al `nginx-pod` desde otros pods, incluido `backend-pod`.

---

## Pregunta 9: Configuración Dinámica con Secrets
1. **Crea un Secret llamado `db-credentials` con las siguientes claves:**
- `username=admin`
- `password=SuperSecretPassword`

2. **Crea un Deployment llamado `secure-backend` que:**
- Use la imagen `nginx:alpine`.
- Tenga 2 réplicas.
- Exponga las credenciales como variables de entorno desde el Secret `db-credentials`.

---

## Pregunta 10: Gestión de Jobs y CronJobs
1. **Crea un Job llamado `data-backup` que:**
- Use la imagen `busybox`.
- Ejecute el comando `echo "Backup Complete"` y termine exitosamente.

2. **Crea un CronJob llamado `daily-task` que:**
- Use la imagen `busybox`.
- Ejecute el comando `date` cada minuto.

---

## Pregunta 11: Escalado Horizontal
1. **Crea un Deployment llamado `webapp` que:**
- Use la imagen `nginx`.
- Tenga inicialmente 1 réplica.

2. **Configura un HorizontalPodAutoscaler (HPA) para este Deployment que:**
- Escale de 1 a 5 réplicas.
- Base el escalado en el uso promedio de CPU, comenzando a escalar cuando exceda el 50%.

---

## Pregunta 12: Volúmenes Configurados con SubPaths
**Crea un pod llamado `web-with-logs` que:**
1. Use la imagen `nginx`.
2. Monte un volumen llamado `shared-data` de tipo `emptyDir` en `/mnt`.
3. Configure dos subpath mounts:
- Montar el subpath `/mnt/html` en `/usr/share/nginx/html`.
- Montar el subpath `/mnt/logs` en `/var/log/nginx`.

---

## Pregunta 13: Canary Deployment
**Realiza un despliegue canary de una aplicación web:**
1. **Crea un Deployment llamado `web-v1` que:**
- Use la imagen `nginx:1.21`.
- Tenga 3 réplicas.

2. **Crea un segundo Deployment llamado `web-v2` que:**
- Use la imagen `nginx:1.23`.
- Tenga 1 réplica.

3. Configura un servicio que distribuya el tráfico entre ambas versiones en proporción 75% (`web-v1`) y 25% (`web-v2`).

---

## Pregunta 14: Rollbacks
1. **Crea un Deployment llamado `api-deployment` que:**
- Use la imagen `nginx:1.21`.

2. Realiza una actualización a la versión `nginx:1.22`.

3. Simula un error y realiza un rollback a la versión anterior.

---

## Pregunta 15: Policies y Recursos
1. **Crea un pod llamado `resource-limited` que:**
- Use la imagen `nginx`.
- Limite el uso de CPU a `200m` y la memoria a `512Mi`.
- Establezca una solicitud de CPU de `100m` y memoria de `256Mi`.

---
